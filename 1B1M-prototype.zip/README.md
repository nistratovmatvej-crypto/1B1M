# 1B1M — Prototype 0.1.0

**One Block, One Meter.** Vanilla-style world-generation overhaul concept. No new biomes, structures, blocks, or gameplay systems.

## Prototype contents
- Seed-stable multi-scale terrain sampler (continental signal, connected ridges, broader valley shaping, local detail).
- Region classification for plains / forest / hills / mountain areas.
- Forest patch density and sparse-plains tree-placement signal.
- Deterministic tree height variation, configurable within a range.
- Properties-based config loader with validation and defaults.
- Determinism and validation tests; sample-performance CLI.
- Fabric project scaffold for Minecraft 26.3.

**Important limitation:** this is an algorithm prototype, not an in-game terrain mod yet. Fabric entrypoint loads the config, but the sampler is not wired into Minecraft's chunk-generation pipeline. No actual terrain, biome, river, or tree generation is altered in-game in this build. The next milestone is to integrate the sampler into the real WorldGen pipeline and test a generated world.

## Config file
`config/1b1m.properties` includes terrain scales/strengths, plains roughness, forest density and patch scale, biome transition width, and tree-height range. At Fabric runtime, the config is created/read at `config/1b1m.properties`.

## Test the prototype math (Java 21+)
```sh
javac -d out $(find src/main/java/dev/onebym/core src/test/java/dev/onebym/core -name '*.java')
java -ea -cp out dev.onebym.core.PrototypeTests
java -cp out dev.onebym.core.PrototypeRunner 123456789 100000
```

## Fabric project
Minecraft 26.3 requires Java 25+. Use JDK 25 and Gradle 9.6+ with Fabric Loom. Version pins are in `gradle.properties`; check the official Fabric version selector before updates.
```sh
gradle build
```
The mod JAR will be in `build/libs/` after a successful Gradle build.
